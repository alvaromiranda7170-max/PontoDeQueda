PONTO DE QUEDA — PROJETO ANDROID

Este pacote coloca o jogo HTML original dentro de um app Android em tela cheia e orientação paisagem.

COMO GERAR O APK:
1. Instale o Android Studio em um computador.
2. Abra o Android Studio e escolha Open.
3. Selecione a pasta PontoDeQuedaAndroid (a pasta que contém settings.gradle).
4. Aguarde o Gradle sincronizar e aceite a instalação do Android SDK se solicitado.
5. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
6. Quando terminar, clique em Locate para encontrar o APK.

PARA ATUALIZAR O JOGO DEPOIS:
- Substitua app/src/main/assets/index.html pela nova versão HTML.
- Aumente versionCode em app/build.gradle (por exemplo, 2, depois 3...).
- Gere um novo APK e instale por cima do anterior, mantendo a mesma assinatura de chave.

OBSERVAÇÕES:
- Este ambiente não tem Android SDK nem Gradle instalados, então o APK compilado não foi gerado aqui.
- O HTML original foi mantido. O jogo usa uma fonte do Google Fonts, que pode precisar de internet para carregar.
- O projeto usa Android Gradle Plugin 8.7.3 e compileSdk 35.
